## 保存频道数据

在保存数据之前我们需要先获取频道组和分类信息

![](/assets/新增频道.png)

### 1、获取频道组信息

#### 接口分析

**请求方式**： GET  `/meiduo_admin/goods/channel_types/`

**请求参数**： 通过请求头传递jwt token数据。

**返回数据**：  JSON

```json
 [
        {
            "id": 1,
            "name": "旅游生活"
        },
        {
            "id": 2,
            "name": "图书音像"
        }
    ]
```

| 返回值 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| Id | int | 是 | id |
| name | 数组 | 是 | 名称 |

### 2、获取一级分类信息

#### 接口分析

**请求方式**： GET   `meiduo_admin/goods/categories/`

**请求参数**： 通过请求头传递jwt token数据。

**返回数据**：  JSON

```json
 [
        {
            "id": "一级分类id",
            "name": "一级分类名称"
        },
        ...
    ]
```

| 返回值 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| Id | int | 是 | 一级分类ID |
| name | 数组 | 是 | 一级分类名 |

### 3、保存数据

#### 接口分析

**请求方式**：POST   `meiduo_admin/goods/channels/`

**请求参数**： 通过请求头传递jwt token数据。

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| group\_id | int | 是 | 频道组id |
| category\_id | int | 是 | 分类id |
| url | str | 是 | 链接 |
| sequence | int | 是 | 排序 |

**返回数据**：  JSON

```json
 {
        "id":39,
        "group":"手机数码",
        "group_id":1,"category":"手机",
        "category_id":1,
        "url":"xxx",
        "sequence":1}
   }
```



