## 删除频道表数据

#### 接口分析

**请求方式**： Delte   `/meiduo_admin/goods/channels/(?P<pk>\d+)/`

**请求参数**： 通过请求头传递jwt token数据。

在路径中携带删除的频道的id值

**返回数据**：  JSON

返回空

