## 查询获取频道列表数据

### 接口分析

**请求方式**： GET   `/meiduo_admin/goods/channels/`

**请求参数**： 通过请求头传递jwt token数据。

**返回数据**：  JSON

```json
 {
        "counts": "频道总数量",
        "lists": [
            {
                "id":10,
                "group":"家居家装",
                "group_id":3,
                "category":"厨具",
                "category_id":10,
                "create_time":"2018-04-09T09:19:50.561302Z",
                "update_time":"2018-04-09T09:19:50.561364Z",
                "url":"javascript:;",
                "sequence":4
            },
            ...
          ],
          "page": "页码",
          "pages": "总页数",
          "pagesize": "页容量"
      }
```

| 返回值 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| count | int | 是 | 总量 |
| lists | 数组 | 是 | 频道表信息 |
| page | int | 是 | 页码 |
| pages | int | 是 | 总页数 |
| pagesize | int | 是 | 页容量 |



