## 修改频道数据

在保存数据之前我们需要获取频道信息

![](/assets/修改频道.png)

### 1、获取频道信息

#### 接口分析

**请求方式**： GET  `/meiduo_admin/goods/channels/(?P<pk>)/`

**请求参数**： 通过请求头传递jwt token数据。

**返回数据**：  JSON

```json
 {
        "id":39,
        "group":"手机数码",
        "group_id":1,"category":"手机",
        "category_id":1,
        "url":"xxx",
        "sequence":1}
   }
```

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| group\_id | int | 是 | 频道组id |
| category\_id | int | 是 | 分类id |
| url | str | 是 | 链接 |
| sequence | int | 是 | 排序 |

### 2、修改数据

#### 接口分析

**请求方式**：PUT   `meiduo_admin/goods/channels/(?P<pk>)/`

**请求参数**： 通过请求头传递jwt token数据。

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| group\_id | int | 是 | 频道组id |
| category\_id | int | 是 | 分类id |
| url | str | 是 | 链接 |
| sequence | int | 是 | 排序 |

**返回数据**：  JSON

```json
 {
        "id":39,
        "group":"手机数码",
        "group_id":1,"category":"手机",
        "category_id":1,
        "url":"xxx",
        "sequence":1}
   }
```



