#!/bin/bash
# 使用 node 版本 6.15.1
gitbook build --gitbook=2.6.7