# Nginx + uwsgi 部署



