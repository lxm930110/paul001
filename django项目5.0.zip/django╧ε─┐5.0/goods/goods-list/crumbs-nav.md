# 列表页面包屑导航

完成之后, 呈现的效果: 

<img src="/goods/images/111.png" style="zoom:50%">

