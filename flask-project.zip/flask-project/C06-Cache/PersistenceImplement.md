# 持久化类实现

<extoc></extoc>

## 1. 持久化类的设计

- 类似缓存层设计, 持久化类也可以 **用面向对象的形式进行数据增删改查**
- 下面以 统计用户作品数量 为例 进行设计和实现

#### 存储类设计

| 持久化名称 | key                    | 类型   | value  |
| -- | ---------------------- | ------ | ------------ | 
| 所有用户的作品数量 | user:all:art_count | zset | [{value: 用户id, score: 11}, {}..] |

- 用户作品数量统计类 `UserArtCountStorage`
    - 属性 
        - redis的键:  `key`   
    - 方法
        - 获取数据:   `get()`    
        - 更新数据:   `update()`  

&nbsp;

## 2. 持久化类实现

- 在 `common/cache`包中创建 `statistic.py`文件, 存放持久化类
- 在 `statistic.py`文件中 定义用户作品数量存储类, 并实现 获取数据 和 更新数据 方法
- 头条项目中使用 **Redis主从** 来存储持久化数据, 主从数据库启动了哨兵模式和持久化机制

```python
# common/cache/statistic.py

# 数据对象/集合 -> 类    键值对 -> 对象

# 所有用户的作品数量
# user:all:art_count   zset   [{value: 用户id, score: 11}, {}..]

# class 用户作品数量类
# 方法
#   get()  获取数据
#   update()  更新数据

from app import redis_slave, redis_master


class UserArtCountStorage:
    """用户作品数量统计类"""
    key = 'user:all:art_count'  # redis的键

    @classmethod
    def get(cls, userid):
        """获取数据"""
        count = redis_slave.zscore(cls.key, userid)  # b'11' / None
        return int(count) if count else 0

    @classmethod
    def update(cls, userid, count=1):
        """更新数据"""
        redis_master.zincrby(cls.key, userid, count)  # zincrby(键, 值, 增加的分数)

```

&nbsp;

## 3. 统计基类的设计

- 除了用户作品数量, 还有其他的统计数据需要进行存储类的设计, 但是其类型基本都采用 `zset`形式, 且基本行为相同: 都需要 获取和更新数据
- 可以定义 **统计存储基类** 来抽取统计存储类的相同内容

- 在 `statistic.py`文件中 定义统计存储基类, 进行代码抽取

```python
# common/cache/statistic.py

from app import redis_slave, redis_master


class BaseCountStorage:
    """统计基类"""
    @classmethod
    def get(cls, userid):
        """获取数据"""
        count = redis_slave.zscore(cls.key, userid)  # b'11' / None
        return int(count) if count else 0

    @classmethod
    def update(cls, userid, count=1):
        """更新数据"""
        redis_master.zincrby(cls.key, userid, count)  # zincrby(键, 值, 增加的分数)


class UserArtCountStorage(BaseCountStorage):
    """用户作品数量统计类"""
    key = 'user:all:art_count'  # redis的键


class UserFollowCountStorage(BaseCountStorage):
    """用户关注数量统计类"""
    key = 'user:all:follow'


class UserFansCountStorage(BaseCountStorage):
    """用户粉丝数量统计类"""
    key = 'user:all:fans'
```

## 4. 接口测试

- 由于不再从Mysql中获取统计数据, 所以需要修改 模型序列化方法 和 查询的字段

- 在 `common/models/user.py`文件中, 修改 模型序列化方法

```python
# common/models/user.py


class User(db.Model):
    """
    用户基本信息
    """
    __tablename__ = 'user_basic'

    id = db.Column('user_id', db.Integer, primary_key=True, doc='用户ID')
    mobile = db.Column(db.String, doc='手机号')
    name = db.Column('user_name', db.String, doc='昵称')
    last_login = db.Column(db.DateTime, doc='最后登录时间')
    introduction = db.Column(db.String, doc='简介')
    # article_count = db.Column(db.Integer, default=0, doc='作品数')
    # following_count = db.Column(db.Integer, default=0, doc='关注的人数')
    # fans_count = db.Column(db.Integer, default=0, doc='粉丝数')
    profile_photo = db.Column(db.String, doc='头像')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'photo': self.profile_photo,
            'intro': self.introduction,
            # 'art_count': self.article_count,
            # 'follow_count': self.following_count,
            # 'fans_count': self.fans_count
        }
```

- 在 `common/cache/user.py`文件中, 修改获取缓存方法

```python
# common/cache/user.py


class UserCache:
    """用户数据缓存类"""

    ...

    def get(self):
        """获取数据"""

        # 先从缓存中读取数据
        data = redis_cluster.get(self.key)

        if data:  # 如果有, 还需要判断缓存值是否为默认值

            ...

        else:  # 如果没有, 从数据库中查询

            # 查询数据库  不再查询 统计数据
            user = User.query.options(
                load_only(User.id, User.name, User.profile_photo, User.introduction)).filter(User.id == self.userid).first()

           ...

```

- 已经实现了统计数据存储类, 接下来就可以改写个人信息 和 用户关注接口, 对统计存储类进行测试

- 在 `app/resources/user/profile.py`文件中, 修改 获取用户信息 视图函数

```python
# app/resources/user/profile.py

...

from cache.statistic import UserArtCountStorage, UserFollowCountStorage, UserFansCountStorage


class CurrentUserResource(Resource):
    """个人中心-当前用户"""
    method_decorators = {'get': [login_required]}

    def get(self):
        # 获取用户id
        userid = g.userid

        # 查询用户数据
        user_cache = UserCache(userid).get()
        
        if user_cache:
            user_cache['art_count'] = UserArtCountStorage.get(userid)
            user_cache['follow_count'] = UserFollowCountStorage.get(userid)
            user_cache['fans_count'] = UserFansCountStorage.get(userid)

            return user_cache
        else:
            return {'message': "Invalid User", 'data': None}, 400


```

- 在 `app/resources/article/following.py`文件中, 修改 用户关注 & 取消用户关注 视图函数

```python
# app/resources/article/following.py

...

from cache.statistic import UserFollowCountStorage, UserFansCountStorage

...


class FollowUserResource(Resource):
    method_decorators = {'post': [login_required], 'get': [login_required]}

    def post(self):
        # 获取参数
        userid = g.userid
        parser = RequestParser()
        parser.add_argument('target', required=True, location='json', type=int)
        args = parser.parse_args()
        author_id = args.target

        # 查询关系表中是否存在关系记录
        relation_obj = Relation.query.options(load_only(Relation.id)).\
            filter(Relation.user_id == userid, Relation.author_id == author_id).first()

        if relation_obj: # 如果存在, 则更新关系
            relation_obj.relation = Relation.RELATION.FOLLOW

        else:  # 如果不存在, 则新增关系

            relation = Relation(userid=userid, author_id=author_id, relation=Relation.RELATION.FOLLOW, update_time=datetime.now())
            db.session.add(relation)

        # 统计字段(关注数量, 粉丝数量) 进行更新
        UserFollowCountStorage.update(userid, 1)
        UserFansCountStorage.update(author_id, 1)

        db.session.commit()

        # 返回结果
        return {'target': author_id}


class UnFollowUserResource(Resource):
    method_decorators = {'delete': [login_required]}

    def delete(self, target):
        # 获取参数
        userid = g.userid

        # 更新数据的关系字段
        Relation.query.filter(Relation.user_id == userid, Relation.author_id == target, Relation.relation == Relation.RELATION.FOLLOW).update({'relation': 0})

        # 将统计字段进行更新
        UserFollowCountStorage.update(userid, -1)
        UserFansCountStorage.update(target, -1)

        db.session.commit()

        return {'target': target}

```





- 运行程序并测试